from django.db import models


class mymodel12(models.Model):
    naa = models.CharField(max_length=30)
    agg = models.IntegerField()
    mnn = models.IntegerField()

    def __str__(self):
        return self.naa

