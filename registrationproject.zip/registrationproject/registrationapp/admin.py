from django.contrib import admin
from registrationapp.models import mymodel12


class myadmin(admin.ModelAdmin):
    list_display=['naa','agg','mnn']

admin.site.register(mymodel12,myadmin)