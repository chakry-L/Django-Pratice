from django.shortcuts import render,redirect
from django.contrib.messages import success
from registrationapp.models import mymodel12


def maiview(request):
    return render(request,'main.html')

def register(request):
    return render(request,'register.html')

def viewdata(request):
    datacollect =mymodel12.objects.all()
    return render(request,'viewdata.html',{'data':datacollect})


def takedatatodb(request):
    nn = request.POST['name1']
    aa = request.POST.get('age1')
    mm =request.POST.get('mno1')
    # a = {'na':nn,'ag':aa,'mm':mm}
    mymodel12(naa=nn,agg=aa,mnn=mm).save()
    success(request,'SAVED SUCCESSFULLY!!!')
    return redirect('viewdata')
