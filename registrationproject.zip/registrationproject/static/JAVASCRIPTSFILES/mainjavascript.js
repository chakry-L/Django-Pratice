function check()
{
    var aa = document.getElementById('id1').value
    if (aa.length==!10)
    {
        alert('GIVEN NAME IS SMALLER')
        return false
    }
    return true
}