from django.db import models

# Create your models here.



class Datamodel(models.Model):
    TextData = models.TextField()


