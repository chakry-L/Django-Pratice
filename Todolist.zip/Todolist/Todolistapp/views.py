from django.shortcuts import render,redirect
from Todolistapp.models import Datamodel
from django.http import HttpResponse


def mytodo(request,dd=None):
    if dd is None:
        dd=Datamodel.objects.all()
        return render(request, 'todo.html' ,{'ddd':dd})
    else:
        return render(request, 'todo.html',{'ddd':dd})


def datatodb(request):
    dt = request.POST.get('name1')
    Datamodel(TextData = dt).save()
    db_data =Datamodel.objects.all()
    return mytodo(request,db_data)
    # return render(request,'out.html',{'ddd':db_data})

def delete(request,ref_num):
    del_data = Datamodel.objects.filter(id=ref_num)
    del_data.delete()

    db_data = Datamodel.objects.all()
    return mytodo(request, db_data)


# def update(request):
#     ref_num = request.POST.get('mn')
#     # update_data = Datamodel.objects.filter(id=ref_num)
#     # return render(request,'out.html',{'aa':ref_num})
#     return HttpResponse(f'check the data here{ref_num}')

